# nodex-0

A starter template for nodex service project.

## install

npm install

## run

npm run start

npm run dev
npm run stage
npm run prod

npm run debug:dev
npm run debug:stage
npm run debug:prod
